<?php include 'partials/header.php'; ?>
<main>
  <h2>About Us</h2>
  <p>We are a passionate travel agency helping you find amazing places around the globe.</p>
</main>
<?php include 'partials/footer.php'; ?>