<footer>
  <p>&copy; 2025 Tour & Travel. All rights reserved.</p>
</footer>
</body>
</html>