<?php include 'partials/header.php'; ?>
<main>
  <h2>Explore the World with Us!</h2>
  <p>Welcome to our travel and tour website. Discover your next adventure.</p>
</main>
<?php include 'partials/footer.php'; ?>