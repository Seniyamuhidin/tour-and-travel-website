<?php include 'partials/header.php'; ?>
<main>
  <h2>Contact Us</h2>
  <form action="#" method="post">
    <input type="text" name="name" placeholder="Your Name" required><br><br>
    <input type="email" name="email" placeholder="Your Email" required><br><br>
    <textarea name="message" placeholder="Your Message" required></textarea><br><br>
    <button type="submit">Send</button>
  </form>
</main>
<?php include 'partials/footer.php'; ?>